package com;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Crawler {
	public void process() {
		File file = new File("result.txt");
		String URL = "https://www.apartments.com/off-campus-housing/ca/los-angeles/university-of-southern-california-university-park-campus";
		System.out.println("Crawling start.");
		List<ApartmentInfo> apartmentInfoList = crawlApartmentInfo(URL);
		System.out.println("File write start. File path: " + file.getAbsolutePath());
		ApartmentFileWriter.write(file, apartmentInfoList);
		System.out.println("All process done.");
	}

	public List<ApartmentInfo> crawlApartmentInfo(String URL) {
		List<ApartmentInfo> apartmentInfoList = new ArrayList<>();
		for (int page = 1; page <= 28; page++) {
			try {
				String pageUrl = URL + "/" + page;
				System.out.println(page + " Page Crawling...");
				Document document = Jsoup.connect(pageUrl).get();
				List<ApartmentInfo> apartmentInfoListByPage = new ArrayList<>();
				Elements nameList = document.select("div.placardContainer ul li a.placardTitle");
				for (int i = 0; i < nameList.size(); i++) {
					Element nameElement = nameList.get(i);
					String name = nameElement.text().trim();
					apartmentInfoListByPage.add(new ApartmentInfo(name));
				}
				Elements locationList = document.select("div.placardContainer ul li div.location");
				for (int i = 0; i < locationList.size(); i++) {
					Element locationElement = locationList.get(i);
					String location = locationElement.text().trim();
					apartmentInfoListByPage.get(i).setLocation(location);
				}

				Elements phoneNumberList = document.select("div.placardContainer ul li div.phone");
				for (int i = 0; i < phoneNumberList.size(); i++) {
					Element phoneNumberElement = phoneNumberList.get(i);
					String phoneNumber = phoneNumberElement.text().trim();
					apartmentInfoListByPage.get(i).setPhoneNumber(phoneNumber);
				}

				Elements priceList = document.select("div.placardContainer ul li span.altRentDisplay");
				for (int i = 0; i < priceList.size(); i++) {
					Element priceElement = priceList.get(i);
					String price = priceElement.text().trim();
					apartmentInfoListByPage.get(i).setPrice(price);
				}
				apartmentInfoList.addAll(apartmentInfoListByPage);
			} catch (IOException e) {
				System.err.println("For '" + URL + "': " + e.getMessage());
			}
		}

		return apartmentInfoList;
	}

	public static void main(String[] args) {
		new Crawler().process();
	}

}