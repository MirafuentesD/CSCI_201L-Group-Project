package com;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

public class ApartmentFileWriter {
	public static void write(File file, List<ApartmentInfo> apartmentInfoList) {
		try (FileWriter fw = new FileWriter(file)) {
			fw.write("NAME,\tLOCATION,\tPHONE_NUMBER,\tPRICE\n");
			for (ApartmentInfo apartmentInfo : apartmentInfoList) {
				fw.write(apartmentInfo.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}