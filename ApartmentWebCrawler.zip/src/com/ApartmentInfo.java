package com;

public class ApartmentInfo {
	private String name;
	private String location;
	private String phoneNumber;
	private String price;

	public ApartmentInfo(String name) {
		this.name = name;
	}

	public ApartmentInfo(String name, String location, String phoneNumber, String price) {
		this.name = name;
		this.location = location;
		this.phoneNumber = phoneNumber;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getPrice() {
		return price;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return name + ",\t" + location + ",\t" + phoneNumber + ",\t" + price + "\n";
	}

}
